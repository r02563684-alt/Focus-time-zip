# FocusTime Android starter

A native Android starter app built with Kotlin + Jetpack Compose.

## Included
- Premium dark theme
- Study and Normal timer modes
- Start, pause, reset
- Study presets (25/45/60 minutes)
- Normal presets (5/15/30 minutes)
- Custom hours/minutes/seconds
- Completed-session counter

## Open and run
1. Install Android Studio.
2. Choose **Open** and select this `FocusTimeAndroid` folder.
3. Let Gradle sync finish.
4. Run the `app` configuration on an Android device or emulator.

## Current limitations
- The countdown runs while the app is open; background operation and persistent notifications are not included yet.
- Session count is in-memory and resets when the app process restarts.
- This is source code, not a signed APK. Build an APK in Android Studio using Build > Build Bundle(s) / APK(s) > Build APK(s).

Package: `com.example.focustime`
