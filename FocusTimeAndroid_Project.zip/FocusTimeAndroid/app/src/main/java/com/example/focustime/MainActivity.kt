package com.example.focustime

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay

private val Bg = Color(0xFF0B0D14)
private val Panel = Color(0xFF171B29)
private val Purple = Color(0xFF9B7BFF)
private val Muted = Color(0xFF9AA3B2)
private val Green = Color(0xFF68D6A5)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { FocusTimeApp() }
    }
}

@Composable
fun FocusTimeApp() {
    var mode by remember { mutableStateOf("Study") }
    var title by remember { mutableStateOf("Deep work") }
    var totalSeconds by remember { mutableIntStateOf(25 * 60) }
    var remaining by remember { mutableIntStateOf(25 * 60) }
    var running by remember { mutableStateOf(false) }
    var completed by remember { mutableIntStateOf(0) }
    var hours by remember { mutableStateOf("0") }
    var minutes by remember { mutableStateOf("25") }
    var seconds by remember { mutableStateOf("0") }

    LaunchedEffect(running) {
        while (running && remaining > 0) {
            delay(1000)
            if (running && remaining > 0) remaining -= 1
        }
        if (running && remaining == 0) {
            running = false
            completed += 1
        }
    }

    fun setTimer(label: String, secs: Int, selectedMode: String = mode) {
        mode = selectedMode
        title = label
        totalSeconds = secs.coerceAtLeast(1)
        remaining = totalSeconds
        running = false
    }

    val progress = if (totalSeconds > 0) remaining.toFloat() / totalSeconds else 0f
    val display = "%02d:%02d:%02d".format(remaining / 3600, (remaining % 3600) / 60, remaining % 60)

    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Purple, secondary = Green, background = Bg,
            surface = Panel, onBackground = Color.White, onSurface = Color.White
        )
    ) {
        Surface(modifier = Modifier.fillMaxSize(), color = Bg) {
            Column(
                modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(18.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("FOCUSTIME", color = Purple, fontSize = 12.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
                        Text("Make time count.", color = Color.White, fontSize = 25.sp, fontWeight = FontWeight.Bold)
                    }
                    Surface(shape = CircleShape, color = Panel) {
                        Icon(Icons.Default.DarkMode, contentDescription = null, tint = Purple, modifier = Modifier.padding(13.dp))
                    }
                }

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    ModeChip("Study", mode == "Study") { mode = "Study"; setTimer("Study session", remaining, "Study") }
                    ModeChip("Normal", mode == "Normal") { mode = "Normal"; setTimer("Custom timer", remaining, "Normal") }
                }

                Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(28.dp)) {
                    Column(Modifier.fillMaxWidth().padding(22.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(title.uppercase(), color = Muted, fontSize = 11.sp, letterSpacing = 2.sp)
                        Spacer(Modifier.height(18.dp))
                        Box(contentAlignment = Alignment.Center, modifier = Modifier.size(220.dp)) {
                            CircularProgressIndicator(
                                progress = { progress }, modifier = Modifier.fillMaxSize(),
                                color = Purple, trackColor = Color(0xFF303449), strokeWidth = 9.dp
                            )
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text(display, fontSize = 36.sp, fontWeight = FontWeight.Bold, color = Color.White)
                                Text(if (running) "FOCUSING" else if (remaining == 0) "COMPLETED" else "READY", color = Muted, fontSize = 11.sp, letterSpacing = 2.sp)
                            }
                        }
                        Spacer(Modifier.height(22.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            Button(
                                onClick = { if (remaining == 0) remaining = totalSeconds; running = !running },
                                colors = ButtonDefaults.buttonColors(containerColor = Purple),
                                shape = RoundedCornerShape(16.dp),
                                modifier = Modifier.weight(1f).height(52.dp)
                            ) {
                                Icon(if (running) Icons.Default.Pause else Icons.Default.PlayArrow, contentDescription = null)
                                Spacer(Modifier.width(6.dp))
                                Text(if (running) "Pause" else "Start", fontWeight = FontWeight.Bold)
                            }
                            OutlinedButton(
                                onClick = { running = false; remaining = totalSeconds },
                                shape = RoundedCornerShape(16.dp),
                                modifier = Modifier.size(52.dp),
                                contentPadding = PaddingValues(0.dp)
                            ) { Icon(Icons.Default.Refresh, contentDescription = "Reset", tint = Color.White) }
                        }
                    }
                }

                if (mode == "Study") {
                    SectionTitle("QUICK STUDY SESSIONS")
                    Row(horizontalArrangement = Arrangement.spacedBy(9.dp)) {
                        PresetCard("25 min", "Pomodoro", Modifier.weight(1f)) { setTimer("Pomodoro", 25 * 60, "Study") }
                        PresetCard("45 min", "Focus", Modifier.weight(1f)) { setTimer("Focus session", 45 * 60, "Study") }
                        PresetCard("60 min", "Long study", Modifier.weight(1f)) { setTimer("Long study", 60 * 60, "Study") }
                    }
                } else {
                    SectionTitle("NORMAL TIMER PRESETS")
                    Row(horizontalArrangement = Arrangement.spacedBy(9.dp)) {
                        PresetCard("5 min", "Short", Modifier.weight(1f)) { setTimer("Short timer", 5 * 60, "Normal") }
                        PresetCard("15 min", "Everyday", Modifier.weight(1f)) { setTimer("Everyday timer", 15 * 60, "Normal") }
                        PresetCard("30 min", "Long", Modifier.weight(1f)) { setTimer("Long timer", 30 * 60, "Normal") }
                    }
                }

                SectionTitle("CREATE YOUR OWN TIMER")
                Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(20.dp)) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Text("Set hours, minutes and seconds", color = Muted, fontSize = 13.sp)
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                            TimeInput("HH", hours, { hours = it })
                            TimeInput("MM", minutes, { minutes = it })
                            TimeInput("SS", seconds, { seconds = it })
                        }
                        Button(
                            onClick = {
                                val h = hours.toIntOrNull()?.coerceIn(0, 99) ?: 0
                                val m = minutes.toIntOrNull()?.coerceIn(0, 59) ?: 0
                                val s = seconds.toIntOrNull()?.coerceIn(0, 59) ?: 0
                                val value = h * 3600 + m * 60 + s
                                if (value > 0) setTimer("My custom timer", value)
                            },
                            modifier = Modifier.fillMaxWidth().height(48.dp),
                            shape = RoundedCornerShape(14.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF29223F))
                        ) { Icon(Icons.Default.AddAlarm, contentDescription = null); Spacer(Modifier.width(8.dp)); Text("Set custom timer") }
                    }
                }

                Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(18.dp)) {
                    Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.EmojiEvents, tint = Green, contentDescription = null)
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text("Sessions completed", color = Muted, fontSize = 12.sp)
                            Text("$completed", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                        }
                        Text("Keep going", color = Green, fontSize = 12.sp)
                    }
                }
                Text("FocusTime • Your personal timer", color = Color(0xFF626B7C), fontSize = 11.sp, modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center)
            }
        }
    }
}

@Composable
fun ModeChip(label: String, selected: Boolean, onClick: () -> Unit) {
    FilterChip(
        selected = selected, onClick = onClick, label = { Text(label) },
        leadingIcon = { Icon(if (label == "Study") Icons.Default.MenuBook else Icons.Default.Timer, null, modifier = Modifier.size(17.dp)) },
        colors = FilterChipDefaults.filterChipColors(
            selectedContainerColor = Color(0xFF30264D), selectedLabelColor = Color.White,
            containerColor = Panel, labelColor = Muted, selectedLeadingIconColor = Purple, leadingIconColor = Muted
        )
    )
}

@Composable
fun SectionTitle(text: String) {
    Text(text, color = Muted, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.5.sp)
}

@Composable
fun PresetCard(time: String, label: String, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Card(onClick = onClick, modifier = modifier, colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(16.dp)) {
        Column(Modifier.padding(vertical = 14.dp, horizontal = 8.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text(time, color = Purple, fontSize = 17.sp, fontWeight = FontWeight.Bold)
            Text(label, color = Muted, fontSize = 10.sp, textAlign = TextAlign.Center)
        }
    }
}

@Composable
fun TimeInput(label: String, value: String, onValue: (String) -> Unit) {
    Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
        Text(label, color = Muted, fontSize = 10.sp)
        Spacer(Modifier.height(5.dp))
        BasicTextField(
            value = value, onValueChange = { onValue(it.filter(Char::isDigit).take(2)) },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
            singleLine = true, textStyle = androidx.compose.ui.text.TextStyle(
                color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center
            ),
            modifier = Modifier.fillMaxWidth().background(Color(0xFF252A3A), RoundedCornerShape(12.dp)).padding(12.dp)
        )
    }
}
